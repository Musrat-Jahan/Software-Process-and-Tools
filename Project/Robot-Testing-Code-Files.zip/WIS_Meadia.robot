* Settings *
Library  SeleniumLibrary
Library  Collections

* Variables *
${BROWSER}    chrome
${URL}        http://localhost/warehouse-inventory-system-master/home.php 
${ADMIN_USER}  admin
${ADMIN_PASS}  admin
${FILE_INPUT_XPATH}  //input[@type='file' and @name='file_upload']
${UPLOAD_BUTTON_XPATH}  //button[@type='submit' and @name='submit']
${IMAGE_PATH}    C:/Users/Musra/OneDrive/Pictures/Book.png  # Update this with the correct image path
${image_name}  Book.png

* Test Cases *
Go to Website
    [Documentation]  This test case verify user is able to open the URL
    Open Browser  ${URL}  ${Browser}
    Page Should Contain  Welcome

Login to your account
    Input Text    username    admin
    Input Text    password    admin
    Click Button  Login

Go to Meadias
    [Documentation]  Verify that an admin can go to Meadias
    Click Element    xpath=//div[@class='sidebar']//ul//li[5]//a[1]
    Page Should Contain  All Photos

Upload Image
    [Documentation]  Verify that an admin can upload an image.
    # Wait for the file upload element to be visible
    Wait Until Element Is Visible  xpath=//input[@type='file' and @name='file_upload']
    Choose File  xpath=//input[@type='file' and @name='file_upload']  C:\\Users\\Musra\\OneDrive\\Pictures\\Book.png
    Click Button  xpath=//button[@type='submit' and @name='submit']
    Capture Page Screenshot  ${CURDIR}/Upload_Image_Screenshot.png  # Adjust the path as needed


Delete Uploaded Image
    [Documentation]  Click on the delete button for the uploaded image specified by its name.
    ${image_xpath}  Set Variable  //tr[td[contains(text(), '${image_name}')]]//a[contains(@href, 'delete_media.php')]
    Click Element  xpath=${image_xpath}
    Page Should Contain  Photo has been deleted.
    
   


    
