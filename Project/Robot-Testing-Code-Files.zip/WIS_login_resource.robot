*** Settings ***
Library  SeleniumLibrary

*** Variables ***
${URL}       http://localhost/warehouse-inventory-system-master/index.php 
${Browser}   chrome

*** Keywords ***
Go to Website
    [Documentation]  Open the login page
    Open Browser  ${URL}  ${Browser}
    Maximize Browser Window
    Page Should Contain  Welcome

Input username
    [Arguments]  ${username}    
    Input Text    username    ${username}

Input passwords
    [Arguments]  ${password}    
    Input Text    password    ${password}

Submit Credentials
    Click Button  Login

