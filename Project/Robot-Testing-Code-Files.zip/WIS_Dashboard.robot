* Settings *
Library  SeleniumLibrary
Library  Collections

* Variables *
${BROWSER}    chrome
${URL}        http://localhost/warehouse-inventory-system-master/home.php 
${ADMIN_USER}  admin
${ADMIN_PASS}  admin

* Test Cases *
Go to Website
    [Documentation]  This test case verify user is able to open the URL
    Open Browser  ${URL}  ${Browser}
    Page Should Contain  Welcome

Login to your account
    Input Text    username    admin
    Input Text    password    admin
    Click Button  Login

Go to Dashboard
    [Documentation]  Verify that an admin can go to dashboard
    Click Element    xpath=//div[@class='sidebar']//ul//li[1]//a[1]

    
