* Settings *
Library  SeleniumLibrary
Library  Collections

* Variables *
${BROWSER}    chrome
${URL}        http://localhost/warehouse-inventory-system-master/home.php 
${ADMIN_USER}  admin
${ADMIN_PASS}  admin

* Test Cases *
Go to Website
    [Documentation]  This test case verify user is able to open the URL
    Open Browser  ${URL}  ${Browser}
    Page Should Contain  Welcome

Login to your account
    Input Text    username    admin
    Input Text    password    admin
    Click Button  Login

Go to Sales
    [Documentation]  Verify that an admin can go to Sales
    Click Element  xpath=//a[@class='submenu-toggle']//span[text()='Sales']
    Sleep  1 seconds  # Pauses the test execution for 1 seconds

View Sales Details
    [Documentation]  Verify that an admin can view Sales details
    Click Link  xpath=//a[text()='Manage Sales']
    Sleep  1 seconds  # Pauses the test execution for 1 seconds

Add New Sale
    [Documentation]  Verify that an admin can add new Sale
    Click Link  xpath=//a[@class='btn btn-primary']
    Page Should Contain    Sale Eidt
    Sleep  1 seconds  # Pauses the test execution for 1 seconds

Find New Sale Product
    [Documentation]  Verify that an admin can find sale product
    Input Text    title    Product1
    Click Button  Find It
    Sleep  1 seconds  # Pauses the test execution for 1 seconds

Go to Sales Again
    [Documentation]  Verify that an admin can go to Sales
    Click Element  xpath=//a[@class='submenu-toggle']//span[text()='Sales']
    Sleep  1 seconds  # Pauses the test execution for 1 seconds

Go to Add Sale
    [Documentation]  Verify that an admin can go to Add Sale
    Click Link  xpath=//a[text()='Add Sale']
    Sleep  1 seconds  # Pauses the test execution for 1 seconds
