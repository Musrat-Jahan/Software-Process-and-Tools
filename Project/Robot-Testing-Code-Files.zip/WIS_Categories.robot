* Settings *
Library  SeleniumLibrary
Library  Collections

* Variables *
${BROWSER}    chrome
${URL}        http://localhost/warehouse-inventory-system-master/home.php 
${ADMIN_USER}  admin
${ADMIN_PASS}  admin

* Test Cases *
Go to Website
    [Documentation]  This test case verify user is able to open the URL
    Open Browser  ${URL}  ${Browser}
    Page Should Contain  Welcome

Login to your account
    Input Text    username    admin
    Input Text    password    admin
    Click Button  Login

Go to Categories
    [Documentation]  Verify that an admin can go to Categories
    Click Element  xpath=//span[text()='Categories']
    Sleep  1 seconds  # Pauses the test execution for 1 seconds

Add New Category
    Input Text    categorie-name    DefaultCategory
    Click Button  Add categorie
    Sleep  1 seconds  # Pauses the test execution for 1 seconds

Go to Edit Category
    [Documentation]  Verify that an admin can edit Category
    Click Element  xpath=//table//tr[1]//td[3]//div[@class='btn-group']//a[@data-original-title='Edit']
    Sleep  1 seconds  # Pauses the test execution for 1 seconds

Edit Category
    Input Text    categorie-name    Default Category
    Click Button  Update categorie
    Sleep  1 seconds  # Pauses the test execution for 1 seconds

Remove Category
    [Documentation]  Verify that an admin can edit Category
    Click Element  xpath=//table//tr[1]//td[3]//div[@class='btn-group']//a[@data-original-title='Remove']
    Sleep  1 seconds  # Pauses the test execution for 1 seconds

