* Settings *
Library  SeleniumLibrary
Library  Collections

* Variables *
${BROWSER}    chrome
${URL}        http://localhost/warehouse-inventory-system-master/home.php 
${ADMIN_USER}  admin
${ADMIN_PASS}  admin

* Test Cases *
Go to Website
    [Documentation]  This test case verify user is able to open the URL
    Open Browser  ${URL}  ${Browser}
    Page Should Contain  Welcome

Login to your account
    Input Text    username    admin
    Input Text    password    admin
    Click Button  Login

Go to User Management
    [Documentation]  Verify that an admin can go to User Management
    Click Element  xpath=//a[@class='submenu-toggle']//span[text()='User Management']
    Sleep  1 seconds  # Pauses the test execution for 1 seconds

View Group Details
    [Documentation]  Verify that an admin can view group details
    Click Link  xpath=//a[text()='Manage Groups']
    Sleep  1 seconds  # Pauses the test execution for 1 seconds

Add New Group
    [Documentation]  Verify that an admin can add new group
    Click Link  xpath=//a[@class='btn btn-info pull-right btn-sm']
    Page Should Contain    Add new user Group
    Sleep  1 seconds  # Pauses the test execution for 1 seconds

Add New User Group
    Input Text    group-name    Default10
    Input Text    group-level   10
    Select From List By Label  xpath=//select[@name='status']  Active
    Click Button  Update
    Sleep  1 seconds  # Pauses the test execution for 1 seconds

Go to User Management Again
    [Documentation]  Verify that an admin can go to User Management
    Click Element  xpath=//a[@class='submenu-toggle']//span[text()='User Management']
    Sleep  1 seconds  # Pauses the test execution for 1 seconds

View Group Details Again
    [Documentation]  Verify that an admin can view group details
    Click Link  xpath=//a[text()='Manage Groups']
    Sleep  1 seconds  # Pauses the test execution for 1 seconds

Go to Edit Group
    [Documentation]  Verify that an admin can edit group
    Click Element  xpath=//table//tr[4]//td[5]//div[@class='btn-group']//a[@data-original-title='Edit']
    Page Should Contain    Edit Group
    Sleep  1 seconds  # Pauses the test execution for 1 seconds

Edit Existing User Group
    Input Text    group-name    Default11
    Input Text    group-level   11
    Select From List By Label  xpath=//select[@name='status']  Deactive
    Click Button  Update
    Sleep  1 seconds  # Pauses the test execution for 1 seconds

Go to User Management Again From Edit Page
    [Documentation]  Verify that an admin can go to User Management
    Click Element  xpath=//a[@class='submenu-toggle']//span[text()='User Management']
    Sleep  1 seconds  # Pauses the test execution for 1 seconds

View Group Details Again After Edit Operation
    [Documentation]  Verify that an admin can view group details
    Click Link  xpath=//a[text()='Manage Groups']
    Sleep  1 seconds  # Pauses the test execution for 1 seconds

Go to Delete Group
    [Documentation]  Verify that an admin can delete group
    Click Element  xpath=//table//tr[4]//td[5]//div[@class='btn-group']//a[@data-original-title='Remove']
    Page Should Contain    Group has been deleted
    Sleep  1 seconds  # Pauses the test execution for 1 seconds
