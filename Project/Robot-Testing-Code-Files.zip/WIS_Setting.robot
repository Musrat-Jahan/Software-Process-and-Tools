* Settings *
Library  SeleniumLibrary
Library  Collections

* Variables *
${BROWSER}    chrome
${URL}        http://localhost/warehouse-inventory-system-master/index.php
${ADMIN_USER}  admin
${ADMIN_PASS}  admin
${FILE_INPUT_XPATH}  //input[@type='file' and @name='file_upload']
${UPLOAD_BUTTON_XPATH}  //button[@type='submit' and @name='submit']
${IMAGE_PATH}  C:\\Users\\synth\\OneDrive\\Pictures\\1.png    # Update this with the correct image path
${image_name}  Upload_Image_Screenshot.png

* Test Cases *
Go to Website
    [Documentation]  This test case verify user is able to open the URL
    Open Browser  ${URL}  ${Browser}
    Page Should Contain  Welcome

Login to your account
    Input Text    username    admin
    Input Text    password    admin
    Click Button  Login

Click Admin User Dropdown
    [Documentation]   Click on the Admin User dropdown to test profile.
    Click Element    //a[@class='toggle' and contains(span, 'Admin User')]


Click Profile Icon
    [Documentation]   Verify that an admin can open the Profile page
    Click Element    xpath=//ul[@class='dropdown-menu']//a[@href='profile.php?id=1']  # Click on the Profile link
    Sleep  1 second  # Pause for a moment after navigation

Click Edit Admin User
    [Documentation]   Verify that an admin can open the Profile page
    Click Element    xpath=//ul[@class='nav nav-pills nav-stacked']//a[@href='edit_account.php']  # Click on the Profile link
    Sleep  1 second  # Pause for a moment after navigation


Click Upload Image
    [Documentation]  Verify that an admin can upload an image.
    # Wait for the file upload element to be visible
    Wait Until Element Is Visible  xpath=//input[@type='file' and @name='file_upload']
    Choose File  xpath=//input[@type='file' and @name='file_upload']  ${IMAGE_PATH}
    Click Button  xpath=//button[@type='submit' and @name='submit']
    Capture Page Screenshot  ${CURDIR}/${image_name}  # Adjust the path as needed

Click Update Admin User Information
    [Documentation]   Verify that an admin can update user details.
    Input Text    name    Admin User
    Input Text    username   admin
    Click Button  update
    Sleep  1 seconds  # Pauses the test execution for 1 seconds

CLick Change password
    [Documentation]   Verify that an admin can change the password
    Click Element    xpath=//a[@href='change_password.php' and @class='btn btn-danger pull-right']  # Click on the Profile link
    Sleep  1 second  # Pause for a moment after navigation


Click Update Password
    [Documentation]   Verify that an admin can change password.
    Input password    new-password    Admin
    Input password    old-password   admin
    Click Button  update
    Sleep  1 seconds  # Pauses the test execution for 1 seconds

