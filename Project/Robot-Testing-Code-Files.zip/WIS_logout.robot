*** Settings ***
Documentation   Logout
Resource  WIS_login_resource.robot
Suite Setup  Go to Website
Suite Teardown  Close Browser

*** Variables ***
${VALID_USER}         admin
${VALID_PASSWORD}     admin
${INVALID_USER}       invalid_user
${INVALID_PASSWORD}   wrong_pw
${EMPTY}              ${EMPTY}

*** Test Cases ***

Logout 
    [Documentation]   Logout from the system
    Login With Valid Credentials Should Succeed  ${VALID_USER}  ${VALID_PASSWORD}
    Logout As Admin User

*** Keywords ***
Login With Valid Credentials Should Succeed
    [Arguments]  ${username}  ${password}
    Input username  ${username}   # Updated locator for username
    Input passwords  ${password}   # Updated locator for password
    Submit Credentials
    Page Should Contain  Welcome

Logout As Admin User
    [Documentation]   Perform logout by clicking on the Admin User dropdown and then Logout.
    Click Admin User Dropdown
    Click Logout Link

Click Admin User Dropdown
    [Documentation]   Click on the Admin User dropdown to reveal the logout option.
    Click Element    //a[@class='toggle' and contains(span, 'Admin User')]

Click Logout Link
    [Documentation]   Click on the Logout link in the dropdown menu.
    Click Element    //li[@class='last']/a
