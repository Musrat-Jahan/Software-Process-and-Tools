* Settings *
Library  SeleniumLibrary
Library  Collections

* Variables *
${BROWSER}    chrome
${URL}        http://localhost/warehouse-inventory-system-master/home.php 
${ADMIN_USER}  admin
${ADMIN_PASS}  admin


* Test Cases *
Go to Website
    [Documentation]  This test case verify user is able to open the URL
    Open Browser  ${URL}  ${Browser}
    Page Should Contain  Welcome

Login to your account
    Input Text    username    admin
    Input Text    password    admin
    Click Button  Login

Go to Sales Report
    [Documentation]  Verify that an admin can go to Sales
    Click Element  xpath=//a[@class='submenu-toggle']//span[text()='Sales Report']
    Sleep  1 seconds  # Pauses the test execution for 1 seconds


View Date Range
    [Documentation]  Verify that an admin can view Sales details
    Click Link  xpath=//a[text()='Sales by dates ']
    Sleep  1 seconds  # Pauses the test execution for 1 seconds
    

Generate Sales by Dates
    Input Text    start-date    2024-10-01
    Click Element    xpath=//td[text()='1']  # Select the 1st day
    Wait Until Element Is Not Visible  xpath=//div[@class='datepicker-days']  # Ensure the start calendar disappears
    Input Text    start-date    2024-10-01
    Input Text    end-date    2024-10-02
    Click Element    xpath=//td[text()='2']  # Select the 2nd day
    Wait Until Element Is Not Visible  xpath=//div[@class='datepicker-days']  # Ensure the end calendar disappears
    Input Text    end-date    2024-10-02
    Click Button  Generate Report
    Sleep  3 seconds  # Pauses the test execution for 1 seconds

Go Back to Previous Page from Report
    Go Back

Go to Sales Report for Date Range
    [Documentation]  Verify that an admin can go to Sales
    Click Element  xpath=//a[@class='submenu-toggle']//span[text()='Sales Report']
    Sleep  1 seconds  # Pauses the test execution for 1 seconds


View Monthly sales
    [Documentation]  Verify that an admin can view Monthly Sales details
    Click Link  xpath=//a[text()='Monthly sales']
    Sleep  1 seconds  # Pauses the test execution for 1 seconds   
 

Go to Sales Report for Daily Sales
    [Documentation]  Verify that an admin can go to Sales
    Click Element  xpath=//a[@class='submenu-toggle']//span[text()='Sales Report']
    Sleep  1 seconds  # Pauses the test execution for 1 seconds


View Daily sales
    [Documentation]  Verify that an admin can view Daily Sales details
    Click Link  xpath=//a[text()='Daily sales']
    Sleep  1 seconds  # Pauses the test execution for 1 seconds