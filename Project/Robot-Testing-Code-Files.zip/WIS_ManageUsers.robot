* Settings *
Library  SeleniumLibrary
Library  Collections

* Variables *
${BROWSER}    chrome
${URL}        http://localhost/warehouse-inventory-system-master/home.php 
${ADMIN_USER}  admin
${ADMIN_PASS}  admin

* Test Cases *
Go to Website
    [Documentation]  This test case verify user is able to open the URL
    Open Browser  ${URL}  ${Browser}
    Page Should Contain  Welcome

Login to your account
    Input Text    username    admin
    Input Text    password    admin
    Click Button  Login

Go to User Management
    [Documentation]  Verify that an admin can go to User Management
    Click Element  xpath=//a[@class='submenu-toggle']//span[text()='User Management']
    Sleep  1 seconds  # Pauses the test execution for 1 seconds

View User Details
    [Documentation]  Verify that an admin can view user details
    Click Link  xpath=//a[text()='Manage Users']
    Sleep  1 seconds  # Pauses the test execution for 1 seconds

Go to Add New User
    [Documentation]  Verify that an admin can add new user
    Click Link  xpath=//a[@class='btn btn-info pull-right' and text()='Add New User']
    Sleep  1 seconds  # Pauses the test execution for 1 seconds

Add New User
    Input Text    full-name    TestUser
    Input Text    username     testuser
    Input Text    password     1234
    Select From List By Label  xpath=//select[@name='level']  User
    Click Button  Add User
    Sleep  1 seconds  # Pauses the test execution for 1 seconds

Go to User Management Again
    [Documentation]  Verify that an admin can go to User Management
    Click Element  xpath=//a[@class='submenu-toggle']//span[text()='User Management']
    Sleep  1 seconds  # Pauses the test execution for 1 seconds

View User Details Again
    [Documentation]  Verify that an admin can view group details
    Click Link  xpath=//a[text()='Manage Users']
    Sleep  1 seconds  # Pauses the test execution for 1 seconds

Go to Edit User
    [Documentation]  Verify that an admin can edit user
    Click Element  xpath=//table//tr[4]//td[7]//div[@class='btn-group']//a[@data-original-title='Edit']
    Page Should Contain    Edit User
    Sleep  1 seconds  # Pauses the test execution for 1 seconds

Edit Existing User
    Input Text    name    Test User
    Input Text    username     testuser
    Select From List By Label  xpath=//select[@name='level']  User
    Select From List By Label  xpath=//select[@name='status']  Deactive
    Sleep  1 seconds  # Pauses the test execution for 1 seconds
    Click Button  Update
    Sleep  1 seconds  # Pauses the test execution for 1 seconds

Edit Existing User Password
    Input Text    password    12345
    Click Button  Change
    Sleep  1 seconds  # Pauses the test execution for 1 seconds

Go to User Management Again From Edit Page
    [Documentation]  Verify that an admin can go to User Management
    Click Element  xpath=//a[@class='submenu-toggle']//span[text()='User Management']
    Sleep  1 seconds  # Pauses the test execution for 1 seconds

View User Details Again After Edit Operation
    [Documentation]  Verify that an admin can view group details
    Click Link  xpath=//a[text()='Manage Users']
    Sleep  1 seconds  # Pauses the test execution for 1 seconds

Delete User
    [Documentation]  Verify that an admin can delete user
    Click Element  xpath=//table//tr[4]//td[7]//div[@class='btn-group']//a[@data-original-title='Remove']
    Sleep  1 seconds  # Pauses the test execution for 1 seconds
