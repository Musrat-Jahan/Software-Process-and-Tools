*** Settings ***
Documentation  Separate Test Cases for Invalid, Valid, Empty Login, Case Sensitivity, and Multiple Failed Attempts
Resource  WIS_login_resource.robot
Suite Setup  Go to Website
Suite Teardown  Close Browser

*** Variables ***
${VALID_USER}         admin
${VALID_PASSWORD}     admin
${INVALID_USER}       invalid_user
${INVALID_PASSWORD}   wrong_pw
${EMPTY}              ${EMPTY}

*** Test Cases ***

# Valid Login Scenario
Valid Username and Valid Password
    [Documentation]   Test valid username and valid password
    Login With Valid Credentials Should Succeed  ${VALID_USER}  ${VALID_PASSWORD}
    Logout As Admin User
Invalid Username and Valid Password
    [Documentation]   Test invalid username with valid password
    Login With Invalid Credentials Should Fail  ${INVALID_USER}  ${VALID_PASSWORD}

Valid Username and Invalid Password
    [Documentation]   Test valid username with invalid password
    Login With Invalid Credentials Should Fail  ${VALID_USER}    ${INVALID_PASSWORD}

Invalid Username and Invalid Password
    [Documentation]   Test invalid username and invalid password
    Login With Invalid Credentials Should Fail  ${INVALID_USER}  ${INVALID_PASSWORD}


Empty Username and Valid Password
    [Documentation]   Test empty username with valid password
    Login With Invalid Credentials Should Fail  ${EMPTY}  ${VALID_PASSWORD}

Valid Username and Empty Password
    [Documentation]   Test valid username with empty password
    Login With Invalid Credentials Should Fail  ${VALID_USER}  ${EMPTY}

Empty Username and Empty Password
    [Documentation]   Test empty username and empty password
    Login With Invalid Credentials Should Fail  ${EMPTY}  ${EMPTY}



Different Case Username and Valid Password
    [Documentation]   Test login functionality with a username in different case and valid password
    Login With Valid Credentials Should Succeed  ${VALID_USER.upper()}  ${VALID_PASSWORD}
    Logout As Admin User
    Login With Valid Credentials Should Succeed  ${VALID_USER.lower()}  ${VALID_PASSWORD}
    Logout As Admin User

Multiple Failed Login Attempts
    [Documentation]   Test login functionality after multiple failed login attempts
    FOR    ${index}    IN RANGE    3
        Login With Invalid Credentials Should Fail  ${INVALID_USER}  ${INVALID_PASSWORD}
    END
    Login With Valid Credentials Should Succeed  ${VALID_USER}  ${VALID_PASSWORD}
    Logout As Admin User

Logout 
    [Documentation]   Logout from system
    Login With Valid Credentials Should Succeed  ${VALID_USER}  ${VALID_PASSWORD}
    Click Admin User Dropdown
    Click Logout Link

*** Keywords ***

Login With Invalid Credentials Should Fail
    [Arguments]  ${username}  ${password}
    Input username  ${username}   # Updated locator for username
    Input passwords  ${password}    # Updated locator for password
    Submit Credentials
    
    # Check specific cases for empty username and password
    Run Keyword If  '${username}' == '' and '${password}' == ''  
    ...  Page Should Contain  Username can't be blank.
    
    # Check case for empty username only
    Run Keyword If  '${username}' == '' and '${password}' != ''
    ...  Page Should Contain  Username can't be blank.
    
    # Check case for empty password only
    Run Keyword If  '${username}' != '' and '${password}' == ''
    ...  Page Should Contain  Password can't be blank.
    
    # Check for invalid username and password case
    Run Keyword If  '${username}' != '' and '${password}' != ''
    ...  Page Should Contain  Sorry Username/Password incorrect.

Login With Valid Credentials Should Succeed
    [Arguments]  ${username}  ${password}
    Input username  ${username}   # Updated locator for username
    Input passwords  ${password}   # Updated locator for password
    Submit Credentials
    Page Should Contain  Welcome

Click Admin User Dropdown
    [Documentation]   Click on the Admin User dropdown to reveal the logout option.
    Click Element    //a[@class='toggle' and contains(span, 'Admin User')]

Click Logout Link
    [Documentation]   Click on the Logout link in the dropdown menu.
    Click Element    //li[@class='last']/a

Logout As Admin User
    [Documentation]   Perform logout by clicking on the Admin User dropdown and then Logout.
    Click Admin User Dropdown
    Click Logout Link
