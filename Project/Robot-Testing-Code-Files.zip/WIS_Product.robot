* Settings *
Library  SeleniumLibrary
Library  Collections

* Variables *
${BROWSER}    chrome
${URL}        http://localhost/warehouse-inventory/home.php
${ADMIN_USER}  admin
${ADMIN_PASS}  admin

* Test Cases *
Go to Website
    [Documentation]  This test case verify user is able to open the URL
    Open Browser  ${URL}  ${Browser}
    Page Should Contain  Welcome

Login to your account
    Input Text    username    admin
    Input Text    password    admin
    Click Button  Login

*** Test Cases ***
Go to Products
    [Documentation]  Verify that an admin can go to Products
    # Ensure the sidebar is expanded and locate the "Products" section
    Click Link  xpath=//a[@class='submenu-toggle' and span[text()='Products']]
    Sleep  1 seconds  # Pause to allow navigation

View Manage Products
    [Documentation]  Verify that an admin can view products details
    Click Link  xpath=//a[text()='Manage products']
    Sleep  1 seconds  # Pauses the test execution for 1 seconds

Add New
    [Documentation]  Verify that an admin can add new group
    Click Link  xpath=//a[@class='btn btn-primary']
    Page Should Contain    Add New
    Sleep  1 seconds  # Pauses the test execution for 1 seconds

Add New Product
    [Documentation]  Verify that an admin can add a new product
    Input Text    product-title    Test02  # Input product title
    Select From List By Label  xpath=//select[@name='product-categorie']  Test 03  # Select category from dropdown
    Select From List By Label  xpath=//select[@name='product-photo']  test.png  # Select product photo (use the available image)
    Input Text  product-quantity  10  # Input quantity
    Input Text  buying-price  20.00  # Input buying price
    Input Text  saleing-price  30.00  # Input selling price
    Click Button  Add product  # Click "Add Product"
    Sleep  1 seconds  # Pauses the test execution for 1 second
 
Go to Products Again
    [Documentation]  Verify that an admin can go to Products
    # Ensure the sidebar is expanded and locate the "Products" section
    Click Link  xpath=//a[@class='submenu-toggle' and span[text()='Products']]
    Sleep  1 seconds  # Pause to allow navigation

View Manage Products Again
    [Documentation]  Verify that an admin can view products details
    Click Link  xpath=//a[text()='Manage products']
    Sleep  1 seconds  # Pauses the test execution for 1 seconds

Go to Edit Product
    [Documentation]  Verify that an admin can edit product
    Click Element  xpath=//table[@class='table table-bordered']//tr[1]//td[last()]//a[@data-original-title='Edit']
    Page Should Contain    Add New Product 
    Sleep  1 seconds  # Pauses the test execution for 1 seconds

Edit Existing Product 
    [Documentation]  Verify that an admin can change product details
    Input Text    product-title    Test02-update  # Update product title
    Select From List By Label  xpath=//select[@name='product-categorie']  Test 03  # Select category from dropdown
    Select From List By Label  xpath=//select[@name='product-photo']  test.png  # Select product photo (use the available image)
    Input Text  product-quantity  70  # Update quantity
    Input Text  buying-price  70.00  # Update buying price
    Input Text  saleing-price  50.00  # Update selling price
    Click Button  Update  # Click "Update"
    Sleep  1 seconds  # Pauses the test execution for 1 seconds

Go to Products Again
    [Documentation]  Verify that an admin can go to Products
    # Ensure the sidebar is expanded and locate the "Products" section
    Click Link  xpath=//a[@class='submenu-toggle' and span[text()='Products']]
    Sleep  1 seconds  # Pause to allow navigation

View Manage Products Again
    [Documentation]  Verify that an admin can view products details
    Click Link  xpath=//a[text()='Manage products']
    Sleep  1 seconds  # Pauses the test execution for 1 seconds

Go to Delete Product
    [Documentation]  Verify that an admin can remove product
    Click Element  xpath=//table[@class='table table-bordered']//tr[1]//td[last()]//a[@data-original-title='Delete']
    Page Should Contain    Products deleted.
    Sleep  1 seconds  # Pauses the test execution for 1 seconds
