*** Settings ***
Documentation   A test suite containing tests related to invalid login
Library  SeleniumLibrary
Suite Setup     Go to Website
Suite Teardown  Close Browser
Test Template   Login With Invalid Credentials Should Fail
Resource    resource.robot

*** Test Cases ***                       USERNAME        PASSWORD
T011 Invalid Username                    invalid        ${VALID_PASSWORD}
T012 Invalid Password                    ${VALID_USER}  invalid
T013 Invalid Username and Password       invalid        invalid

