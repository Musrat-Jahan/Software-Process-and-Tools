*** Settings ***
Documentation   A test suite with a single test for valid login
Library  SeleniumLibrary
Resource    resource.robot

*** Test Cases ***
T001 Valid Login
    [Documentation]     Valid user name and password to login
    Go to Website
    Enter username    ${VALID_USER}
    Enter password    ${VALID_PASSWORD}
    Submit Credentials
    [Teardown]      Close Browser


