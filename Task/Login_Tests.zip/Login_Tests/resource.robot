*** Settings ***
Library  SeleniumLibrary

*** Variables ***
${URL}      http://localhost/loginsystem/login.php
${Browser}  chrome
${VALID_USER}   test1
${VALID_PASSWORD}   test1pw
${DELAY}        0.5 seconds

*** Keywords ***
Go to Website
    [Documentation]  This verify that user is able to open the URL
    Set Selenium Speed    ${DELAY}
    Open Browser  ${URL}  ${Browser}
    #Maximize Browser Window
    Page should contain  Login Registration System
    Wait Until Element Is Visible    id:username    timeout=5

Enter username
    [Arguments]  ${username}
    Input Text    username    ${username}

Enter password
    [Arguments]  ${password}
    Input Text    password    ${password}

Submit Credentials
    Click Button    Submit

Login With Invalid Credentials Should Fail
    [Arguments]     ${username}     ${password}
    Enter username    ${username}
    Enter password    ${password}
    Submit Credentials
    Login Should Fail

Login Should Fail
    Page Should Contain Element    xpath://div[@class="alert alert-danger"]