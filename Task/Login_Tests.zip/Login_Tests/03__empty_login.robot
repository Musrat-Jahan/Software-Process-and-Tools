*** Settings ***
Documentation   A test suite containing tests related to empty login
Library  SeleniumLibrary
Suite Setup     Go to Website
Suite Teardown  Close Browser
Test Template   Login With Invalid Credentials Should Fail
Resource    resource.robot

*** Test Cases ***                       USERNAME        PASSWORD
T021 Empty Username                      ${EMPTY}        ${VALID_PASSWORD}
T022 Empty Password                      ${VALID_USER}   ${EMPTY}
T023 Empty Username and Password         ${EMPTY}        ${EMPTY}


